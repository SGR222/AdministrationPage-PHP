<?php
require_once __DIR__ . '/../config/Database.php';

class FamilyModel
{
    private $db;

    public function __construct()
    {
        $database = new Database();
        $this->db = $database->getConnection();
    }

    public function getAllFamilies(): array
    {
        $query = "SELECT * FROM families";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function createFamilyWithId(string $id, string $naam, string $adres, int $boekjaar_id): bool
    {
        $stmt = $this->db->prepare("INSERT INTO families (id, naam, adres, boekjaar_id) VALUES (:id, :naam, :adres, :boekjaar_id)");
        $stmt->bindValue(':id', $id, PDO::PARAM_STR);
        $stmt->bindValue(':naam', $naam, PDO::PARAM_STR);
        $stmt->bindValue(':adres', $adres, PDO::PARAM_STR);
        $stmt->bindValue(':boekjaar_id', $boekjaar_id, PDO::PARAM_INT);
        return $stmt->execute();
    }

    public function getFamilyById($id): ?array
    {
        $stmt = $this->db->prepare("SELECT * FROM families WHERE id = :id");
        $stmt->bindValue(':id', $id, PDO::PARAM_STR);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result ?: null;
    }

    public function getFamilyWithBoekjaar($family_id): ?array
    {
        $stmt = $this->db->prepare(
            "SELECT families.*, boekjaar.jaar AS boekjaar 
             FROM families 
             LEFT JOIN boekjaar ON families.boekjaar_id = boekjaar.id
             WHERE families.id = :family_id"
        );
        $stmt->bindValue(':family_id', $family_id, PDO::PARAM_STR);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result ?: null;
    }

    public function updateFamily($id, $naam, $adres): bool
    {
        $stmt = $this->db->prepare("UPDATE families SET naam = :naam, adres = :adres WHERE id = :id");
        $stmt->bindValue(':naam', $naam, PDO::PARAM_STR);
        $stmt->bindValue(':adres', $adres, PDO::PARAM_STR);
        $stmt->bindValue(':id', $id, PDO::PARAM_STR);
        return $stmt->execute();
    }

    public function deleteFamily($id): bool
    {
        // Verwijder eerst alle leden (en hun contributies)
        $stmt = $this->db->prepare("DELETE FROM members WHERE family_id = :id");
        $stmt->bindValue(':id', $id, PDO::PARAM_STR);
        $stmt->execute();

        // Verwijder daarna de familie
        $stmt = $this->db->prepare("DELETE FROM families WHERE id = :id");
        $stmt->bindValue(':id', $id, PDO::PARAM_STR);
        return $stmt->execute();
    }
}
