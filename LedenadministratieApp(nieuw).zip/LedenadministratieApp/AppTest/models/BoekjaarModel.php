<?php
require_once __DIR__ . '/../config/Database.php';

class BoekjaarModel
{
    private $db;

    public function __construct()
    {
        $database = new Database();
        $this->db = $database->getConnection();
    }

    public function getAllBoekjaren()
    {
        $stmt = $this->db->prepare("SELECT * FROM boekjaar ORDER BY jaar DESC");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getBoekjaarById($id)
    {
        $stmt = $this->db->prepare("SELECT * FROM boekjaar WHERE id = :id");
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function createBoekjaar($jaar)
    {
        $stmt = $this->db->prepare("INSERT INTO boekjaar (jaar) VALUES (:jaar)");
        $stmt->bindValue(':jaar', $jaar, PDO::PARAM_INT);
        return $stmt->execute();
    }
}
