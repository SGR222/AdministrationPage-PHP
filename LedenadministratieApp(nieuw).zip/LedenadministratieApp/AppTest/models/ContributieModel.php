<?php
require_once __DIR__ . '/../config/Database.php';

class ContributieModel
{
    private $db;

    public function __construct()
    {
        $database = new Database();
        $this->db = $database->getConnection();
    }

    public function getContributiesByFamily($familyId, $jaar)
    {
        $stmt = $this->db->prepare(
            "SELECT c.*, m.naam FROM contributies c
             JOIN members m ON c.member_id = m.id
             WHERE m.family_id = :family_id AND c.jaar = :jaar"
        );
        $stmt->bindValue(':family_id', $familyId, PDO::PARAM_STR);
        $stmt->bindValue(':jaar', $jaar, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getTotaalContributieByFamily($family_id, $jaar)
    {
        $stmt = $this->db->prepare(
            "SELECT SUM(bedrag) as totaal FROM contributies 
         WHERE jaar = :jaar AND member_id IN (
            SELECT id FROM members WHERE family_id = :family_id
         )"
        );
        $stmt->bindValue(':jaar', $jaar, PDO::PARAM_INT);
        $stmt->bindValue(':family_id', $family_id, PDO::PARAM_STR);
        $stmt->execute();
        return $stmt->fetchColumn() ?: 0;
    }

    public function addContributie($memberId, $jaar, $bedrag)
    {
        $stmt = $this->db->prepare(
            "INSERT INTO contributies (member_id, jaar, bedrag) VALUES (:member_id, :jaar, :bedrag)"
        );
        $stmt->bindValue(':member_id', $memberId, PDO::PARAM_INT);
        $stmt->bindValue(':jaar', $jaar, PDO::PARAM_INT);
        $stmt->bindValue(':bedrag', $bedrag);
        return $stmt->execute();
    }

    public function deleteContributie($contributieId)
    {
        $stmt = $this->db->prepare("DELETE FROM contributies WHERE id = :id");
        $stmt->bindValue(':id', $contributieId, PDO::PARAM_INT);
        return $stmt->execute();
    }

    public function updateFamilyKorting($familyId, $korting)
    {
        $stmt = $this->db->prepare("UPDATE families SET korting = :korting WHERE id = :id");
        $stmt->bindValue(':korting', $korting, PDO::PARAM_STR); // korting als decimaal
        $stmt->bindValue(':id', $familyId, PDO::PARAM_STR);
        return $stmt->execute();
    }

    public function getFamilyKorting($familyId)
    {
        $stmt = $this->db->prepare("SELECT korting FROM families WHERE id = :id");
        $stmt->bindValue(':id', $familyId, PDO::PARAM_STR);
        $stmt->execute();
        return $stmt->fetchColumn();
    }
}
