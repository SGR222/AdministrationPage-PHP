<?php
require_once __DIR__ . '/../config/Database.php';

class MemberModel
{
    private $db;

    public function __construct()
    {
        $database = new Database();
        $this->db = $database->getConnection();
    }

    public function getMembersByFamily($family_id): array
    {
        $stmt = $this->db->prepare("SELECT * FROM members WHERE family_id = :family_id");
        $stmt->bindValue(':family_id', $family_id, PDO::PARAM_STR);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getMemberById($id): ?array
    {
        $stmt = $this->db->prepare("SELECT * FROM members WHERE id = :id");
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result ?: null;
    }

    public function addMember($familyId, $naam, $leeftijd, $soort_lid): int
    {
        $stmt = $this->db->prepare("INSERT INTO members (family_id, naam, leeftijd, soort_lid) VALUES (:family_id, :naam, :leeftijd, :soort_lid)");
        $stmt->bindValue(':family_id', $familyId, PDO::PARAM_STR);
        $stmt->bindValue(':naam', $naam, PDO::PARAM_STR);
        $stmt->bindValue(':leeftijd', $leeftijd, PDO::PARAM_INT);
        $stmt->bindValue(':soort_lid', $soort_lid, PDO::PARAM_STR);
        $stmt->execute();
        return (int)$this->db->lastInsertId();
    }

    public function updateMember($id, $naam, $leeftijd, $soort_lid): bool
    {
        $stmt = $this->db->prepare("UPDATE members SET naam = :naam, leeftijd = :leeftijd, soort_lid = :soort_lid WHERE id = :id");
        $stmt->bindValue(':naam', $naam, PDO::PARAM_STR);
        $stmt->bindValue(':leeftijd', $leeftijd, PDO::PARAM_INT);
        $stmt->bindValue(':soort_lid', $soort_lid, PDO::PARAM_STR);
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        return $stmt->execute();
    }

    public function deleteMember($id): bool
    {
        $stmt = $this->db->prepare("DELETE FROM members WHERE id = :id");
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        return $stmt->execute();
    }

    public function calculateContribution($geboortedatum, $boekjaar)
    {
        $leeftijd = date('Y', strtotime($boekjaar)) - date('Y', strtotime($geboortedatum));

        $query = "SELECT * FROM soort_lid WHERE :leeftijd BETWEEN min_leeftijd AND max_leeftijd";
        $stmt = $this->db->prepare($query);
        $stmt->bindValue(':leeftijd', $leeftijd, PDO::PARAM_INT);
        $stmt->execute();
        $soortLid = $stmt->fetch();

        if (!$soortLid) {
            return null;
        }

        $basisbedrag = 100.00;
        $contributie = $basisbedrag - ($basisbedrag * ($soortLid['korting'] / 100));

        return $contributie;
    }
}
