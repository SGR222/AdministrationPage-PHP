<?php
require_once __DIR__ . '/../config/Database.php';

class AdminModel
{
    private $db;

    public function __construct()
    {
        $database = new Database();
        $this->db = $database->getConnection();
    }

    public function getAllFamiliesWithBoekjaar(): array
    {
        $query = "SELECT families.*, boekjaar.jaar AS boekjaar 
                  FROM families 
                  LEFT JOIN boekjaar ON families.boekjaar_id = boekjaar.id
                  ORDER BY families.naam ASC";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getMembersByFamily($family_id): array
    {
        $stmt = $this->db->prepare("SELECT * FROM members WHERE family_id = :family_id");
        $stmt->bindValue(':family_id', $family_id, PDO::PARAM_STR);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getTotaalContributieByFamily($family_id, $jaar): float
    {
        $stmt = $this->db->prepare(
            "SELECT SUM(bedrag) as totaal FROM contributies 
             WHERE jaar = :jaar AND member_id IN (
                SELECT id FROM members WHERE family_id = :family_id
             )"
        );
        $stmt->bindValue(':jaar', $jaar, PDO::PARAM_INT);
        $stmt->bindValue(':family_id', $family_id, PDO::PARAM_STR);
        $stmt->execute();
        return floatval($stmt->fetchColumn() ?: 0);
    }

    public function getFamilyById($id): ?array
    {
        $stmt = $this->db->prepare("SELECT * FROM families WHERE id = :id");
        $stmt->bindValue(':id', $id, PDO::PARAM_STR);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result ?: null;
    }

    public function updateFamilyId($oldId, $newId): bool
    {
        // Update het ID in families
        $stmt = $this->db->prepare("UPDATE families SET id = :newId WHERE id = :oldId");
        $stmt->bindValue(':newId', $newId, PDO::PARAM_STR);
        $stmt->bindValue(':oldId', $oldId, PDO::PARAM_STR);
        $stmt->execute();

        // Update het family_id in members
        $stmt = $this->db->prepare("UPDATE members SET family_id = :newId WHERE family_id = :oldId");
        $stmt->bindValue(':newId', $newId, PDO::PARAM_STR);
        $stmt->bindValue(':oldId', $oldId, PDO::PARAM_STR);
        return $stmt->execute();
    }

    public function updateMember($id, $naam, $leeftijd, $soort_lid): bool
    {
        $stmt = $this->db->prepare("UPDATE members SET naam = :naam, leeftijd = :leeftijd, soort_lid = :soort_lid WHERE id = :id");
        $stmt->bindValue(':naam', $naam, PDO::PARAM_STR);
        $stmt->bindValue(':leeftijd', $leeftijd, PDO::PARAM_INT);
        $stmt->bindValue(':soort_lid', $soort_lid, PDO::PARAM_STR);
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        return $stmt->execute();
    }

    public function addMember($familyId, $naam, $leeftijd, $soort_lid): int
    {
        $stmt = $this->db->prepare("INSERT INTO members (family_id, naam, leeftijd, soort_lid) VALUES (:family_id, :naam, :leeftijd, :soort_lid)");
        $stmt->bindValue(':family_id', $familyId, PDO::PARAM_STR);
        $stmt->bindValue(':naam', $naam, PDO::PARAM_STR);
        $stmt->bindValue(':leeftijd', $leeftijd, PDO::PARAM_INT);
        $stmt->bindValue(':soort_lid', $soort_lid, PDO::PARAM_STR);
        $stmt->execute();
        return (int)$this->db->lastInsertId();
    }

    public function deleteMember($id): bool
    {
        $stmt = $this->db->prepare("DELETE FROM members WHERE id = :id");
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        return $stmt->execute();
    }

    public function deleteFamily($id): bool
    {
        // Verwijder eerst alle leden van de familie
        $stmt = $this->db->prepare("DELETE FROM members WHERE family_id = :id");
        $stmt->bindValue(':id', $id, PDO::PARAM_STR);
        $stmt->execute();

        // Verwijder daarna de familie zelf
        $stmt = $this->db->prepare("DELETE FROM families WHERE id = :id");
        $stmt->bindValue(':id', $id, PDO::PARAM_STR);
        return $stmt->execute();
    }

    public function addFamilyWithMember(array $data): bool
    {
        try {
            $this->db->beginTransaction();

            // Controleer of de familie-ID al bestaat
            $checkQuery = "SELECT id FROM families WHERE id = :id";
            $stmt = $this->db->prepare($checkQuery);
            $stmt->bindParam(':id', $data['id_code'], PDO::PARAM_STR);
            $stmt->execute();
            if ($stmt->rowCount() > 0) {
                throw new Exception("De ID-code bestaat al. Kies een andere.");
            }

            // Haal het huidige boekjaar op of voeg toe
            $currentYear = date('Y');
            $boekjaarQuery = "SELECT id FROM boekjaar WHERE jaar = :jaar";
            $stmt = $this->db->prepare($boekjaarQuery);
            $stmt->bindParam(':jaar', $currentYear, PDO::PARAM_INT);
            $stmt->execute();
            $boekjaar = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$boekjaar) {
                $insertBoekjaar = "INSERT INTO boekjaar (jaar) VALUES (:jaar)";
                $stmt = $this->db->prepare($insertBoekjaar);
                $stmt->bindParam(':jaar', $currentYear, PDO::PARAM_INT);
                $stmt->execute();
                $boekjaar_id = $this->db->lastInsertId();
            } else {
                $boekjaar_id = $boekjaar['id'];
            }

            // Voeg familie toe
            $query = "INSERT INTO families (id, naam, adres, boekjaar_id) VALUES (:id, :naam, :adres, :boekjaar_id)";
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(':id', $data['id_code'], PDO::PARAM_STR);
            $stmt->bindParam(':naam', $data['naam'], PDO::PARAM_STR);
            $stmt->bindParam(':adres', $data['adres'], PDO::PARAM_STR);
            $stmt->bindParam(':boekjaar_id', $boekjaar_id, PDO::PARAM_INT);
            $stmt->execute();

            // Voeg eerste familielid toe
            $query = "INSERT INTO members (family_id, naam, leeftijd, soort_lid) VALUES (:family_id, :naam, :leeftijd, :soort)";
            $stmt = $this->db->prepare($query);
            $stmt->bindParam(':family_id', $data['id_code'], PDO::PARAM_STR);
            $stmt->bindParam(':naam', $data['member_naam'], PDO::PARAM_STR);
            $stmt->bindParam(':leeftijd', $data['member_leeftijd'], PDO::PARAM_INT);
            $stmt->bindParam(':soort', $data['member_soort'], PDO::PARAM_STR);
            $stmt->execute();

            $this->db->commit();
            return true;
        } catch (Exception $e) {
            $this->db->rollBack();
            throw $e;
        }
    }
}
