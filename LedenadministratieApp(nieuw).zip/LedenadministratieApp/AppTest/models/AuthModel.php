<?php
require_once __DIR__ . '/../config/Database.php';

class AuthModel
{
    private $db;

    public function __construct()
    {
        $database = new Database();
        $this->db = $database->getConnection();
    }

    public function loginFamily($family_id, $address, $family_name): ?array
    {
        $stmt = $this->db->prepare(
            "SELECT * FROM families 
             WHERE id = :family_id 
             AND LOWER(adres) = LOWER(:address) 
             AND LOWER(naam) = LOWER(:family_name)"
        );
        $stmt->bindValue(':family_id', $family_id, PDO::PARAM_STR);
        $stmt->bindValue(':address', $address, PDO::PARAM_STR);
        $stmt->bindValue(':family_name', $family_name, PDO::PARAM_STR);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);


        if (!$result) {
            error_log("Login mislukt voor: id=$family_id, adres=$address, naam=$family_name");
        }

        return $result ?: null;
    }

    public function loginAdmin($username): ?array
    {
        $stmt = $this->db->prepare("SELECT * FROM admins WHERE username = :username");
        $stmt->bindValue(':username', $username, PDO::PARAM_STR);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result ?: null;
    }
}
