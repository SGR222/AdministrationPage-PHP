<?php
include __DIR__ . '/../layouts/adminheader.php';
?>
<link rel="stylesheet" href="../../public/assets/css/test.css">
<h1>Familie bewerken (Admin)</h1>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<form method="post" action="">
    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
    <div class="form-group">
        <label for="id">Uniek ID</label>
        <input type="text" name="id" id="id" value="<?= htmlspecialchars($family['id']) ?>" required>
    </div>
    <div class="form-group">
        <label for="naam">Naam</label>
        <input type="text" name="naam" id="naam" value="<?= htmlspecialchars($family['naam']) ?>" required>
    </div>
    <div class="form-group">
        <label for="adres">Adres</label>
        <input type="text" name="adres" id="adres" value="<?= htmlspecialchars($family['adres']) ?>" required>
    </div>
    <button type="submit" name="update_family" class="btn btn-primary">Opslaan</button>
    <a href="../../public/assets/index.php?action=admin_dashboard" class="btn btn-secondary">Annuleren</a>
</form>

<h2>Familieleden</h2>
<?php if (!empty($members)): ?>
    <table class="table">
        <thead>
            <tr>
                <th>Naam</th>
                <th>Leeftijd</th>
                <th>Soort Lid</th>
                <th>Acties</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($members as $member): ?>
                <tr>
                    <form action="" method="POST" class="edit-lid-form">
                        <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                        <td>
                            <input type="text" name="edit_member_naam" value="<?= htmlspecialchars($member['naam']) ?>" required>
                        </td>
                        <td>
                            <input type="number" name="edit_member_leeftijd" value="<?= htmlspecialchars($member['leeftijd']) ?>" required>
                        </td>
                        <td>
                            <select name="edit_member_soort_lid" required>
                                <option value="jeugd" <?= $member['soort_lid'] === 'jeugd' ? 'selected' : '' ?>>Jeugd</option>
                                <option value="aspirant" <?= $member['soort_lid'] === 'aspirant' ? 'selected' : '' ?>>Aspirant</option>
                                <option value="junior" <?= $member['soort_lid'] === 'junior' ? 'selected' : '' ?>>Junior</option>
                                <option value="senior" <?= $member['soort_lid'] === 'senior' ? 'selected' : '' ?>>Senior</option>
                                <option value="oudere" <?= $member['soort_lid'] === 'oudere' ? 'selected' : '' ?>>Oudere</option>
                            </select>
                        </td>
                        <td>
                            <input type="hidden" name="edit_member_id" value="<?= $member['id'] ?>">
                            <button type="submit" class="btn btn-primary">Opslaan</button>
                            <a href="../../public/assets/index.php?action=edit_family&id=<?= urlencode($family['id']) ?>&delete_member=<?= $member['id'] ?>" class="btn btn-danger" onclick="return confirm('Weet je zeker dat je dit lid wilt verwijderen?')">Verwijderen</a>
                        </td>
                    </form>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php else: ?>
    <p><i>Geen familieleden gevonden.</i></p>
<?php endif; ?>

<h2>Familielid toevoegen</h2>
<form action="" method="POST">
    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
    <div class="form-group">
        <label for="member_naam">Naam</label>
        <input type="text" name="member_naam" id="member_naam" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="leeftijd">Leeftijd</label>
        <input type="number" name="leeftijd" id="leeftijd" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="soort_lid">Soort Lid</label>
        <select name="soort_lid" id="soort_lid" class="form-control" required>
            <option value="jeugd">Jeugd</option>
            <option value="aspirant">Aspirant</option>
            <option value="junior">Junior</option>
            <option value="senior">Senior</option>
            <option value="oudere">Oudere</option>
        </select>
    </div>
    <button type="submit" name="add_member" class="btn btn-success">Lid toevoegen</button>
</form>

<a href="../../public/assets/index.php?action=admin_dashboard" class="btn btn-secondary mt-3">Terug naar dashboard</a>
<?php include __DIR__ . '/../layouts/footer.php'; ?>