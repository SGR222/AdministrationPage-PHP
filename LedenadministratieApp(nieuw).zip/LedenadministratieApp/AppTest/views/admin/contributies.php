<?php include __DIR__ . '/../layouts/adminheader.php'; ?>
<link rel="stylesheet" href="../../public/assets/css/test.css">
<h1>Contributies beheren</h1>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<form method="get" action="">
    <input type="hidden" name="action" value="admin_contributies">
    <label for="family_id">Kies familie:</label>
    <select name="family_id" id="family_id" onchange="this.form.submit()">
        <?php foreach ($families as $fam): ?>
            <option value="<?= htmlspecialchars($fam['id']) ?>" <?= $fam['id'] == $selected_family_id ? 'selected' : '' ?>>
                <?= htmlspecialchars($fam['naam']) ?>
            </option>
        <?php endforeach; ?>
    </select>
    <label for="jaar">Jaar:</label>
    <input type="number" name="jaar" id="jaar" value="<?= htmlspecialchars($jaar) ?>" onchange="this.form.submit()">
</form>

<h2>Contributies voor <?= htmlspecialchars($jaar) ?></h2>
<table class="table">
    <thead>
        <tr>
            <th>Lid</th>
            <th>Bedrag</th>
            <th>Acties</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($contributies as $c): ?>
            <tr>
                <td><?= htmlspecialchars($c['naam']) ?></td>
                <td>€ <?= number_format($c['bedrag'], 2, ',', '.') ?></td>
                <td>
                    <a href="../../public/assets/index.php?action=admin_contributies&family_id=<?= urlencode($selected_family_id) ?>&jaar=<?= $jaar ?>&delete_contributie=<?= $c['id'] ?>"
                        class="btn btn-danger"
                        onclick="return confirm('Weet je zeker dat je deze contributie wilt verwijderen?')">Verwijderen</a>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (empty($contributies)): ?>
            <tr>
                <td colspan="3"><i>Geen contributies gevonden.</i></td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>

<h2>Contributie toevoegen</h2>
<form method="post" action="">
    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
    <input type="hidden" name="jaar" value="<?= htmlspecialchars($jaar) ?>">
    <div class="form-group">
        <label for="member_id">Lid:</label>
        <select name="member_id" id="member_id" required>
            <?php foreach ($members as $m): ?>
                <option value="<?= $m['id'] ?>"><?= htmlspecialchars($m['naam']) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="form-group">
        <label for="bedrag">Bedrag (€):</label>
        <input type="number" step="0.01" name="bedrag" id="bedrag" required>
    </div>
    <button type="submit" name="add_contributie" class="btn btn-primary">Toevoegen</button>
</form>

<form method="post" action="">
    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
    <div class="form-group">
        <label for="korting">Korting voor deze familie (%)</label>
        <input type="number" name="korting" id="korting" min="0" max="100" value="<?= isset($korting) ? $korting * 100 : 0 ?>" required>
    </div>
    <button type="submit" name="update_korting" class="btn btn-primary">Korting opslaan</button>
</form>

<a href="../../public/assets/index.php?action=admin_dashboard" class="btn btn-secondary mt-3">Terug naar dashboard</a>
<?php include __DIR__ . '/../layouts/footer.php'; ?>