<?php

include __DIR__ . '/../layouts/adminheader.php';
?>
<link rel="stylesheet" href="../../public/assets/css/test.css">
<h1>Nieuwe Familie Toevoegen (Admin)</h1>

<?php if (!empty($error)): ?>
    <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<form action="../../public/assets/index.php?action=admin_add_family" method="POST">
    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
    <div class="form-group">
        <label for="naam">Familienaam</label>
        <input type="text" name="naam" id="naam" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="adres">Adres</label>
        <textarea name="adres" id="adres" class="form-control" required></textarea>
    </div>
    <div class="form-group">
        <label for="id-code">ID-Code</label>
        <input name="ID" id="id-code" class="form-control" required placeholder="Voer hier een unieke familiecode in">
    </div>
    <div class="form-group">
        <label for="boekjaar_id">Selecteer Boekjaar</label>
        <select name="boekjaar_id" id="boekjaar_id" class="form-control" required>
            <option value="2025" selected>2025</option>
        </select>
    </div>

    <h2>Voeg eerste familielid toe</h2>
    <div class="form-group">
        <label for="member_naam">Naam</label>
        <input type="text" name="member_naam" id="member_naam" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="member_leeftijd">Leeftijd</label>
        <input type="number" name="member_leeftijd" id="member_leeftijd" class="form-control" required>
    </div>
    <div class="form-group">
        <label for="member_soort">Soort lid</label>
        <select name="member_soort" id="member_soort" class="form-control" required>
            <option value="jeugd">Jeugd</option>
            <option value="aspirant">Aspirant</option>
            <option value="junior">Junior</option>
            <option value="senior">Senior</option>
            <option value="oudere">Oudere</option>
        </select>
    </div>

    <button type="submit" class="btn btn-primary">Opslaan</button>
</form>

<a href="../../public/assets/index.php?action=admin_dashboard" class="btn btn-secondary mt-3">Terug naar dashboard</a>
<?php include __DIR__ . '/../layouts/footer.php'; ?>