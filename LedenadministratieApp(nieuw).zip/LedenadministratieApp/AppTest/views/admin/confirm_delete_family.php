<?php
include __DIR__ . '/../layouts/adminheader.php';
?>
<link rel="stylesheet" href="../../public/assets/css/test.css">
<h1>Familie verwijderen</h1>
<p>Weet je zeker dat je familie <b><?= htmlspecialchars($family['naam']) ?></b> wilt verwijderen?</p>
<form method="post" action="">
    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
    <button type="submit" name="confirm_delete" class="btn btn-danger">Ja, verwijderen</button>
    <a href="../../public/assets/index.php?action=admin_dashboard" class="btn btn-secondary">Annuleren</a>
</form>
<?php include __DIR__ . '/../layouts/footer.php'; ?>