<?php include __DIR__ . '/../layouts/adminheader.php'; ?>
<link rel="stylesheet" href="../../public/assets/css/test.css">
<h1>Admin Dashboard</h1>
<p>Welkom, beheerder!</p>

<h2>Overzicht van gezinnen</h2>
<table class="table">
    <thead>
        <tr>
            <th>Gezinsnaam</th>
            <th>Adres</th>
            <th>Boekjaar</th>
            <th>Korting (%)</th>
            <th>Totaal Contributie</th>
            <th>Acties</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($families as $family): ?>
            <tr>
                <td><?= htmlspecialchars($family['naam']) ?></td>
                <td><?= htmlspecialchars($family['adres']) ?></td>
                <td><?= htmlspecialchars($family['boekjaar']) ?></td>
                <td><?= number_format($family['korting'] * 100, 0) ?>%</td>
                <td>&euro;<?= number_format($family['contributie_totaal'], 2) ?></td>
                <td>
                    <a href="../../public/assets/index.php?action=edit_family&id=<?= urlencode($family['id']) ?>" class="btn btn-primary">Bewerken</a>
                    <a href="../../public/assets/index.php?action=confirm_delete_family&id=<?= urlencode($family['id']) ?>" class="btn btn-danger">Verwijder</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
<a href="../../public/assets/index.php?action=logout" class="btn btn-secondary">Uitloggen</a>
<?php include __DIR__ . '/../layouts/footer.php'; ?>