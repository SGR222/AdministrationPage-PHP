<?php
include __DIR__ . '/../layouts/header.php';
?>
<link rel="stylesheet" href="../../public/assets/css/test.css">
<?php if (!isset($family)): ?>
    <p>Geen familie gevonden. <a href="../../public/assets/index.php?action=login">Log opnieuw in.</a></p>
    <?php include __DIR__ . '/../layouts/footer.php';
    exit; ?>
<?php endif; ?>
<h1>Welkom, <?= htmlspecialchars($family['naam']) ?></h1>
<p><b>Adres:</b> <?= htmlspecialchars($family['adres']) ?></p>
<p><b>Boekjaar:</b> <?= htmlspecialchars($family['boekjaar']) ?></p>
<p><b>Korting:</b> <?= isset($family['korting']) ? number_format($family['korting'] * 100, 0) : 0 ?>%</p>
<p><b>Totaal contributie gezin:</b> &euro;<?= number_format($totaal, 2) ?></p>

<h2>Overzicht van contributies</h2>
<table class="table">
    <thead>
        <tr>
            <th>Naam</th>
            <th>Leeftijd</th>
            <th>Soort lid</th>
            <th>Contributie</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($members as $member): ?>
            <tr>
                <td><?= htmlspecialchars($member['naam']) ?></td>
                <td><?= htmlspecialchars($member['leeftijd']) ?></td>
                <td><?= htmlspecialchars($member['soort_lid']) ?></td>
                <td>
                    &euro;<?= number_format(
                                berekenContributie($member['leeftijd'], $member['soort_lid'], $family['korting']),
                                2
                            ) ?>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
<a href="../../public/assets/index.php?action=logout" class="btn btn-danger">Uitloggen</a>
<?php include __DIR__ . '/../layouts/footer.php'; ?>