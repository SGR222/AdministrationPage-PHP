<?php
include __DIR__ . '/../layouts/header.php';
?>
<link rel="stylesheet" href="../../public/assets/css/test.css">
<h1>Mijn Familie</h1>

<?php if (!empty($family)): ?>
    <table class="table">
        <thead>
            <tr>
                <th>Naam</th>
                <th>Adres</th>
                <th>Acties</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><?= htmlspecialchars($family['naam']) ?></td>
                <td><?= htmlspecialchars($family['adres']) ?></td>
                <td>
                    <a href="../../public/assets/index.php?action=dashboard&family_id=<?= $family['id'] ?>" class="btn btn-info">Dashboard</a>
                    <a href="../../public/assets/index.php?action=edit&id=<?= $family['id'] ?>" class="btn btn-warning">Bewerk</a>
                    <a href="../../public/assets/index.php?action=delete&id=<?= $family['id'] ?>" class="btn btn-danger" onclick="return confirm('Weet je zeker dat je deze familie wilt verwijderen?')">Verwijder</a>
                </td>
            </tr>
        </tbody>
    </table>
<?php else: ?>
    <p><i>Geen familie gevonden.</i></p>
<?php endif; ?>

<?php include __DIR__ . '/../layouts/footer.php'; ?>