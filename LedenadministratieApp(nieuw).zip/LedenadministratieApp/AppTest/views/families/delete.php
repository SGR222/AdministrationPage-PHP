<?php
include __DIR__ . '/../layouts/header.php';
?>
<link rel="stylesheet" href="../../public/assets/css/test.css">
<h1>Familie Verwijderen</h1>

<?php if (isset($error_message)): ?>
    <div class="alert alert-danger"><?= htmlspecialchars($error_message) ?></div>
<?php endif; ?>

<p>Weet je zeker dat je deze familie wilt verwijderen? Dit kan niet ongedaan worden gemaakt.</p>

<form method="post" action="">
    <button type="submit" name="confirm_delete" class="btn btn-danger">Ja, verwijderen</button>
    <a href="../../public/assets/index.php?action=index" class="btn btn-secondary">Annuleren</a>
</form>

<?php include __DIR__ . '/../layouts/footer.php'; ?>