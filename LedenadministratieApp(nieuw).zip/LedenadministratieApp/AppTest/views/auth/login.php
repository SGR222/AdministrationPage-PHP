<?php
if (session_status() === PHP_SESSION_NONE) session_start();
?>
<!DOCTYPE html>
<html lang="nl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Familie Login</title>
    <link rel="stylesheet" href="../../public/assets/css/test.css">
</head>

<body>
    
    <div class="form-container">
        <form action="../../public/assets/index.php?action=login" method="post">
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
            <div style="text-align:center; margin-bottom:18px;">
                <svg width="48" height="48" fill="none" viewBox="0 0 48 48">
                    <circle cx="24" cy="24" r="22" fill="#1976d2" opacity="0.13" />
                    <path d="M24 14a6 6 0 1 1 0 12 6 6 0 0 1 0-12zm0 16c5.33 0 16 2.67 16 8v2H8v-2c0-5.33 10.67-8 16-8z" fill="#1976d2" />
                </svg>
            </div>
            <h3>Login voor Families</h3>
            <?php if (isset($error)) {
                echo '<span class="error-msg">' . htmlspecialchars($error) . '</span>';
            } ?>
            <input type="text" name="family_id" required placeholder="Uniek ID-nummer">
            <input type="text" name="address" required placeholder="Adres">
            <input type="text" name="family_name" required placeholder="Familienaam">
            <input type="submit" name="submit" value="Login" class="form-btn">
            <p>Geen account? <a href="../../public/assets/index.php?action=create">Maak er een aan</a></p>
            <p>Ben je een beheerder? <a href="../../views/auth/admin.php">Login als admin</a></p>
        </form>
    </div>
</body>

</html>