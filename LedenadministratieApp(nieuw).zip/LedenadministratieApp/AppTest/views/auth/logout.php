<?php
header("Location: ../../public/assets/index.php?action=login");
exit;
// Noot: Deze code is bedoeld om de gebruiker uit te loggen en terug te sturen naar de loginpagina.