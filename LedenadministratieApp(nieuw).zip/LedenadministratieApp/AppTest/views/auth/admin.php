<?php

if (session_status() === PHP_SESSION_NONE) session_start();
?>
<!DOCTYPE html>
<html lang="nl">

<head>
    <meta charset="UTF-8">
    <title>Admin Login</title>
    <link rel="stylesheet" href="../../public/assets/css/test.css">
</head>

<body>
    <div class="form-container">
        <form action="../../public/assets/index.php?action=admin" method="post">
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
            <h3>Login voor Admin</h3>
            <?php if (isset($error)) {
                echo '<span class="error-msg">' . htmlspecialchars($error) . '</span>';
            } ?>
            <input type=" text" name="username" required placeholder="Gebruikersnaam">
            <input type="password" name="password" required placeholder="Wachtwoord">
            <input type="submit" name="submit" value="Login" class="form-btn">
            <p><a href="login.php">Terug naar familie login</a></p>
        </form>
    </div>
</body>

</html>