<footer class="footer mt-4">
    <div class="container text-center">
        <p>&copy; 2025 Ledenadministratie. Alle rechten voorbehouden.</p>
    </div>
</footer>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pzjw8f+ua7Kw1TIq0pxW76u6rB26pIvdE6vrlXZx8lr95Y2P4lRFS0JUebzyAf9z" crossorigin="anonymous"></script>
</body>

</html>