<!DOCTYPE html>
<html lang="nl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin | Ledenadministratie</title>
    <link rel="stylesheet" href="../../public/assets/css/test.css">
</head>

<body>
    <div class="container">
        <nav class="navbar">
            <a class="navbar-brand" href="../../public/assets/index.php?action=admin_dashboard">Admin Dashboard</a>
            <ul class="navbar-menu">
                <li><a href="../../public/assets/index.php?action=admin_add_family">Gezin toevoegen</a></li>
                <li><a href="../../public/assets/index.php?action=admin_contributies">Contributies beheren</a></li>
                <li><a href="../../public/assets/index.php?action=logout">Uitloggen</a></li>
            </ul>
        </nav>
        <div class="mt-4">
            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-danger">
                    <?= htmlspecialchars($_SESSION['error']); ?>
                    <?php unset($_SESSION['error']); ?>
                </div>
            <?php endif; ?>
        </div>