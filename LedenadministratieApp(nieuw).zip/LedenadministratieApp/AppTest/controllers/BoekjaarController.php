<?php
require_once __DIR__ . '/../models/BoekjaarModel.php';

class BoekjaarController
{
    private $model;

    public function __construct()
    {
        $this->model = new BoekjaarModel();
    }

    public function index()
    {
        $boekjaren = $this->model->getAllBoekjaren();
        require_once __DIR__ . '/../views/boekjaren/index.php';
    }

    public function create()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $jaar = intval($_POST['jaar']);
            if ($jaar > 2000) {
                $this->model->createBoekjaar($jaar);
                header("Location: ../../public/assets/index.php?action=boekjaren");
                exit;
            } else {
                $_SESSION['error'] = "Vul een geldig jaar in!";
            }
        }
        require_once __DIR__ . '/../views/boekjaren/create.php';
    }
}
