<?php
require_once __DIR__ . '/../models/MemberModel.php';

class MemberController
{
    private $model;

    public function __construct()
    {
        $this->model = new MemberModel();
    }

    private function generateCsrfToken()
    {
        if (session_status() === PHP_SESSION_NONE) session_start();
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
    }

    private function checkCsrfToken($token)
    {
        return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
    }

    public function index($familyId)
    {
        $members = $this->model->getMembersByFamily($familyId);
        require_once __DIR__ . '/../views/members/index.php';
    }

    public function create($familyId)
    {
        $error = "";
        $this->generateCsrfToken();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // CSRF check
            if (
                empty($_POST['csrf_token']) ||
                !$this->checkCsrfToken($_POST['csrf_token'])
            ) {
                $error = "Ongeldige sessie, probeer het opnieuw.";
            } else {
                $naam = trim($_POST['naam']);
                $leeftijd = filter_var($_POST['leeftijd'], FILTER_VALIDATE_INT);
                $soort_lid = trim($_POST['soort_lid']);
                $allowed_soorten = ['jeugd', 'aspirant', 'junior', 'senior', 'oudere'];

                if (
                    !$naam || strlen($naam) > 100 ||
                    !$leeftijd || $leeftijd <= 0 || $leeftijd > 120 ||
                    !in_array($soort_lid, $allowed_soorten)
                ) {
                    $error = "Ongeldige of ontbrekende invoer.";
                } else {
                    $this->model->addMember($familyId, $naam, $leeftijd, $soort_lid);
                    header("Location: index.php?action=members&family_id=$familyId");
                    exit;
                }
            }
        }
        require_once __DIR__ . '/../views/members/create.php';
    }

    public function edit($id)
    {
        $error = "";
        $member = $this->model->getMemberById($id);
        $this->generateCsrfToken();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // CSRF check
            if (
                empty($_POST['csrf_token']) ||
                !$this->checkCsrfToken($_POST['csrf_token'])
            ) {
                $error = "Ongeldige sessie, probeer het opnieuw.";
            } else {
                $naam = trim($_POST['naam']);
                $leeftijd = filter_var($_POST['leeftijd'], FILTER_VALIDATE_INT);
                $soort_lid = trim($_POST['soort_lid']);
                $allowed_soorten = ['jeugd', 'aspirant', 'junior', 'senior', 'oudere'];

                if (
                    !$naam || strlen($naam) > 100 ||
                    !$leeftijd || $leeftijd <= 0 || $leeftijd > 120 ||
                    !in_array($soort_lid, $allowed_soorten)
                ) {
                    $error = "Ongeldige of ontbrekende invoer.";
                } else {
                    $this->model->updateMember($id, $naam, $leeftijd, $soort_lid);
                    header("Location: index.php?action=members&family_id=" . $member['family_id']);
                    exit;
                }
            }
        }
        require_once __DIR__ . '/../views/members/edit.php';
    }

    public function delete($id)
    {
        $error = "";
        $member = $this->model->getMemberById($id);
        $this->generateCsrfToken();

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_delete'])) {
            // CSRF check
            if (
                empty($_POST['csrf_token']) ||
                !$this->checkCsrfToken($_POST['csrf_token'])
            ) {
                $error = "Ongeldige sessie, probeer het opnieuw.";
            } else {
                $this->model->deleteMember($id);
                header("Location: index.php?action=members&family_id=" . $member['family_id']);
                exit;
            }
        }
        require_once __DIR__ . '/../views/members/delete.php';
    }
}
