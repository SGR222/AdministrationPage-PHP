<?php
require_once __DIR__ . '/../models/ContributieModel.php';

class ContributieController
{
    private $model;

    public function __construct()
    {
        $this->model = new ContributieModel();
    }

    public function index($familyId, $jaar)
    {
        $contributies = $this->model->getContributiesByFamily($familyId, $jaar);
        $totaal = $this->model->getTotaalContributieByFamily($familyId, $jaar);
        require_once __DIR__ . '/../views/contributies/index.php';
    }

    public function beheer($familyId, $jaar)
    {
        $contributies = $this->model->getContributiesByFamily($familyId, $jaar);
        $totaal = $this->model->getTotaalContributieByFamily($familyId, $jaar);
        $korting = $this->model->getFamilyKorting($familyId);
        $error = "";

        // Korting aanpassen
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_korting'])) {
            $nieuweKorting = floatval($_POST['korting']) / 100;
            if ($nieuweKorting < 0 || $nieuweKorting > 1) {
                $error = "Korting moet tussen 0 en 100% zijn.";
            } else {
                $this->model->updateFamilyKorting($familyId, $nieuweKorting);
                header("Location: ../../public/assets/index.php?action=admin_contributies&family_id=" . urlencode($familyId) . "&jaar=" . $jaar);
                exit();
            }
        }

        // Contributie verwijderen
        if (isset($_GET['delete_contributie'])) {
            $contributieId = intval($_GET['delete_contributie']);
            $this->model->deleteContributie($contributieId);
            header("Location: ../../public/assets/index.php?action=admin_contributies&family_id=" . urlencode($familyId) . "&jaar=" . $jaar);
            exit();
        }

        require_once __DIR__ . '/../views/admin/contributies.php';
    }
}
