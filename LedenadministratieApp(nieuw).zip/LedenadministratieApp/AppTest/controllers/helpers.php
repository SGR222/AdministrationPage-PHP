<?php
require_once __DIR__ . '/helpers.php';
function berekenContributie($leeftijd, $soortLid, $korting = 0)
{
    $basisBedrag = 100;
    $kortingen = [
        'jeugd' => 0.50,
        'aspirant' => 0.40,
        'junior' => 0.25,
        'senior' => 0.00,
        'oudere' => 0.45
    ];

    $bedrag = $basisBedrag * (1 - ($kortingen[$soortLid] ?? 0));
    $bedrag = $bedrag * (1 - $korting);
    return $bedrag;
}
