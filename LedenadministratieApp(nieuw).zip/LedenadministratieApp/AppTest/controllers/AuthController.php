<?php
require_once __DIR__ . '/../models/AuthModel.php';

class AuthController
{
    private $model;

    public function __construct()
    {
        $this->model = new AuthModel();
    }

    private function generateCsrfToken()
    {
        if (session_status() === PHP_SESSION_NONE) session_start();
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
    }

    private function checkCsrfToken($token)
    {
        return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
    }

    public function login()
    {
        $this->generateCsrfToken();
        $error = "";
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // CSRF check
            if (
                empty($_POST['csrf_token']) ||
                !$this->checkCsrfToken($_POST['csrf_token'])
            ) {
                $error = "Ongeldige sessie, probeer het opnieuw.";
            } else {
                $family_id = trim($_POST['family_id']);
                $address = trim($_POST['address']);
                $family_name = trim($_POST['family_name']);

                // Validatie
                if (
                    !$family_id || strlen($family_id) > 20 ||
                    !$address || strlen($address) > 255 ||
                    !$family_name || strlen($family_name) > 100
                ) {
                    $error = 'Ongeldige of ontbrekende invoer!';
                } else {
                    $family = $this->model->loginFamily($family_id, $address, $family_name);
                    if ($family) {
                        if (session_status() === PHP_SESSION_NONE) session_start();
                        $_SESSION['family_id'] = $family['id'];
                        header('Location: ../../public/assets/index.php?action=dashboard&family_id=' . $family['id']);
                        exit();
                    } else {
                        $error = 'Ongeldige gegevens!';
                    }
                }
            }
        }
        if (session_status() === PHP_SESSION_NONE) session_start();
        require __DIR__ . '/../views/auth/login.php';
    }

    public function admin()
    {
        $this->generateCsrfToken();
        $error = "";
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // CSRF check
            if (
                empty($_POST['csrf_token']) ||
                !$this->checkCsrfToken($_POST['csrf_token'])
            ) {
                $error = "Ongeldige sessie, probeer het opnieuw.";
            } else {
                $username = trim($_POST['username']);
                $password = $_POST['password'];

                // Validatie
                if (
                    !$username || strlen($username) > 50 ||
                    !$password || strlen($password) > 255
                ) {
                    $error = 'Ongeldige of ontbrekende invoer!';
                } else {
                    $admin = $this->model->loginAdmin($username);
                    if ($admin && password_verify($password, $admin['password'])) {
                        if (session_status() === PHP_SESSION_NONE) session_start();
                        $_SESSION['admin_id'] = $admin['id'];
                        $_SESSION['admin_username'] = $admin['username'];
                        $_SESSION['admin_logged_in'] = true;
                        header('Location: ../../public/assets/index.php?action=admin_dashboard');
                        exit();
                    } else {
                        $error = 'Ongeldige gebruikersnaam of wachtwoord!';
                    }
                }
            }
        }
        if (session_status() === PHP_SESSION_NONE) session_start();
        require __DIR__ . '/../views/auth/admin.php';
    }

    public function logout()
    {
        if (session_status() === PHP_SESSION_NONE) session_start();
        session_unset();
        session_destroy();
        header("Location: ../../public/assets/index.php?action=login");
        exit;
    }
}
