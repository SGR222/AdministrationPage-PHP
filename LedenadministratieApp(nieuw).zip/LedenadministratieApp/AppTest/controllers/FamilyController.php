<?php
require_once __DIR__ . '/../models/FamilyModel.php';
require_once __DIR__ . '/../models/MemberModel.php';
require_once __DIR__ . '/../models/BoekjaarModel.php';
require_once __DIR__ . '/../models/ContributieModel.php';
require_once __DIR__ . '/helpers.php';

class FamilyController
{
    private $model;
    private $memberModel;

    public function __construct()
    {
        $this->model = new FamilyModel();
        $this->memberModel = new MemberModel();
    }

    private function generateCsrfToken()
    {
        if (session_status() === PHP_SESSION_NONE) session_start();
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
    }

    private function checkCsrfToken($token)
    {
        return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
    }

    public function index()
    {
        if (session_status() === PHP_SESSION_NONE) session_start();
        if (!isset($_SESSION['family_id'])) {
            header('Location: ../../public/assets/index.php?action=login');
            exit();
        }
        $family_id = $_SESSION['family_id'];
        $family = $this->model->getFamilyById($family_id);
        require_once __DIR__ . '/../views/families/index.php';
    }

    public function dashboard()
    {
        if (session_status() === PHP_SESSION_NONE) session_start();
        $family_id = $_GET['family_id'] ?? $_SESSION['family_id'] ?? null;
        if (!$family_id) {
            header('Location: ../../public/assets/index.php?action=login');
            exit();
        }
        $family = $this->model->getFamilyWithBoekjaar($family_id);

        if (!$family) {
            header('Location: ../../public/assets/index.php?action=login&error=family_not_found');
            exit();
        }

        $members = $this->memberModel->getMembersByFamily($family_id);
        $contribModel = new ContributieModel();
        $jaar = date('Y');
        $totaal = $contribModel->getTotaalContributieByFamily($family_id, $jaar);

        if ($totaal == 0 && $members) {
            $totaal = 0;
            foreach ($members as $member) {
                $totaal += berekenContributie($member['leeftijd'], $member['soort_lid'], $family['korting']);
            }
        }

        require_once __DIR__ . '/../views/families/dashboard.php';
    }

    public function create()
    {
        $error = "";
        $boekjaarModel = new BoekjaarModel();
        $memberModel = new MemberModel();

        $this->generateCsrfToken();

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // CSRF check
            if (
                empty($_POST['csrf_token']) ||
                !$this->checkCsrfToken($_POST['csrf_token'])
            ) {
                $error = "Ongeldige sessie, probeer het opnieuw.";
            } else {
                $naam = trim($_POST['naam']);
                $adres = trim($_POST['adres']);
                $id_code = trim($_POST['ID']);
                $boekjaar_id = intval($_POST['boekjaar_id']);
                $member_naam = trim($_POST['member_naam']);
                $member_leeftijd = filter_var($_POST['member_leeftijd'], FILTER_VALIDATE_INT);
                $member_soort = trim($_POST['member_soort']);
                $allowed_soorten = ['jeugd', 'aspirant', 'junior', 'senior', 'oudere'];

                if (
                    !$naam || strlen($naam) > 100 ||
                    !$adres || strlen($adres) > 255 ||
                    !$id_code || strlen($id_code) > 20 ||
                    !$member_naam || strlen($member_naam) > 100 ||
                    !$member_leeftijd || $member_leeftijd <= 0 || $member_leeftijd > 120 ||
                    !in_array($member_soort, $allowed_soorten)
                ) {
                    $error = "Ongeldige of ontbrekende invoer.";
                } else {
                    try {
                        if ($this->model->getFamilyById($id_code)) {
                            throw new Exception("De ID-code bestaat al. Kies een andere.");
                        }
                        $this->model->createFamilyWithId($id_code, $naam, $adres, $boekjaar_id);
                        $memberModel->addMember($id_code, $member_naam, $member_leeftijd, $member_soort);
                        header('Location: ../../public/assets/index.php?action=dashboard&family_id=' . $id_code);
                        exit();
                    } catch (Exception $e) {
                        $error = "Er is iets misgegaan. Probeer het later opnieuw.";
                    }
                }
            }
        }

        $boekjaren = $boekjaarModel->getAllBoekjaren();
        require __DIR__ . '/../views/families/create.php';
    }

    public function show()
    {
        if (session_status() === PHP_SESSION_NONE) session_start();
        if (!isset($_SESSION['family_id'])) {
            header('Location: ../../public/assets/index.php?action=login');
            exit();
        }
        $family_id = $_SESSION['family_id'];
        $family = $this->model->getFamilyById($family_id);
        require_once __DIR__ . '/../views/families/index.php';
    }

    public function edit()
    {
        if (session_status() === PHP_SESSION_NONE) session_start();
        if (!isset($_SESSION['family_id'])) {
            header('Location: ../../public/assets/index.php?action=login');
            exit();
        }
        $family_id = $_SESSION['family_id'];
        $family = $this->model->getFamilyById($family_id);
        $this->generateCsrfToken();

        // Lid bewerken
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_member_id'])) {
            if (
                empty($_POST['csrf_token']) ||
                !$this->checkCsrfToken($_POST['csrf_token'])
            ) {
                $error = "Ongeldige sessie, probeer het opnieuw.";
            } else {
                $member_id = intval($_POST['edit_member_id']);
                $member_naam = trim($_POST['edit_member_naam']);
                $leeftijd = filter_var($_POST['edit_member_leeftijd'], FILTER_VALIDATE_INT);
                $soort_lid = trim($_POST['edit_member_soort_lid']);
                $allowed_soorten = ['jeugd', 'aspirant', 'junior', 'senior', 'oudere'];

                if (
                    !$member_naam || strlen($member_naam) > 100 ||
                    !$leeftijd || $leeftijd <= 0 || $leeftijd > 120 ||
                    !in_array($soort_lid, $allowed_soorten)
                ) {
                    $error = "Ongeldige of ontbrekende invoer.";
                } else {
                    $this->memberModel->updateMember($member_id, $member_naam, $leeftijd, $soort_lid);
                    header("Location: ../../public/assets/index.php?action=edit");
                    exit();
                }
            }
        }

        // Familiegegevens bewerken
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_family'])) {
            if (
                empty($_POST['csrf_token']) ||
                !$this->checkCsrfToken($_POST['csrf_token'])
            ) {
                $error = "Ongeldige sessie, probeer het opnieuw.";
            } else {
                $naam = trim($_POST['naam']);
                $adres = trim($_POST['adres']);
                if (
                    !$naam || strlen($naam) > 100 ||
                    !$adres || strlen($adres) > 255
                ) {
                    $error = "Ongeldige of ontbrekende invoer.";
                } else {
                    $this->model->updateFamily($family_id, $naam, $adres);
                    header('Location: ../../public/assets/index.php?action=edit');
                    exit();
                }
            }
        }

        // Lid toevoegen
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_member'])) {
            if (
                empty($_POST['csrf_token']) ||
                !$this->checkCsrfToken($_POST['csrf_token'])
            ) {
                $error = "Ongeldige sessie, probeer het opnieuw.";
            } else {
                $member_naam = trim($_POST['member_naam']);
                $leeftijd = filter_var($_POST['leeftijd'], FILTER_VALIDATE_INT);
                $soort_lid = trim($_POST['soort_lid']);
                $allowed_soorten = ['jeugd', 'aspirant', 'junior', 'senior', 'oudere'];

                if (
                    !$member_naam || strlen($member_naam) > 100 ||
                    !$leeftijd || $leeftijd <= 0 || $leeftijd > 120 ||
                    !in_array($soort_lid, $allowed_soorten)
                ) {
                    $error = "Ongeldige of ontbrekende invoer.";
                } else {
                    $this->memberModel->addMember($family_id, $member_naam, $leeftijd, $soort_lid);
                    header("Location: ../../public/assets/index.php?action=edit");
                    exit();
                }
            }
        }

        // Lid verwijderen
        if (isset($_GET['delete_member'])) {
            $member_id = intval($_GET['delete_member']);
            $this->memberModel->deleteMember($member_id);
            header("Location: ../../public/assets/index.php?action=edit");
            exit();
        }

        $members = $this->memberModel->getMembersByFamily($family_id);
        require_once __DIR__ . '/../views/families/edit.php';
    }

    public function delete()
    {
        if (session_status() === PHP_SESSION_NONE) session_start();
        if (!isset($_SESSION['family_id'])) {
            header('Location: ../../public/assets/index.php?action=login');
            exit();
        }
        $family_id = $_SESSION['family_id'];
        $this->generateCsrfToken();

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_delete'])) {
            if (
                empty($_POST['csrf_token']) ||
                !$this->checkCsrfToken($_POST['csrf_token'])
            ) {
                $error = "Ongeldige sessie, probeer het opnieuw.";
            } else {
                $this->model->deleteFamily($family_id);
                session_destroy();
                header('Location: ../../public/assets/index.php?action=login');
                exit();
            }
        }

        require_once __DIR__ . '/../views/families/delete.php';
    }
}
