<?php
require_once __DIR__ . '/../models/AdminModel.php';

class AdminController
{
    private $adminModel;

    public function __construct()
    {
        $this->adminModel = new AdminModel();
    }

    private function generateCsrfToken()
    {
        if (session_status() === PHP_SESSION_NONE) session_start();
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
    }

    private function checkCsrfToken($token)
    {
        return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
    }

    public function admin_dashboard()
    {
        if (session_status() === PHP_SESSION_NONE) session_start();
        if (empty($_SESSION['admin_logged_in'])) {
            header('Location: ../../public/assets/index.php?action=admin');
            exit();
        }

        $families = $this->adminModel->getAllFamiliesWithBoekjaar();
        $jaar = date('Y');

        foreach ($families as &$family) {
            $members = $this->adminModel->getMembersByFamily($family['id']);
            $family['contributie_totaal'] = 0;
            if ($members) {
                $totaal = $this->adminModel->getTotaalContributieByFamily($family['id'], $jaar);
                if ($totaal == 0) {
                    $basisBedrag = 100;
                    $kortingen = [
                        'jeugd' => 0.50,
                        'aspirant' => 0.40,
                        'junior' => 0.25,
                        'senior' => 0.00,
                        'oudere' => 0.45
                    ];
                    foreach ($members as $member) {
                        $bedrag = $basisBedrag * (1 - ($kortingen[$member['soort_lid']] ?? 0));
                        $bedrag = $bedrag * (1 - ($family['korting'] ?? 0));
                        $family['contributie_totaal'] += $bedrag;
                    }
                } else {
                    $family['contributie_totaal'] = $totaal;
                }
            }
        }
        unset($family);

        require_once __DIR__ . '/../views/admin/dashboard.php';
    }

    public function edit_family()
    {
        if (session_status() === PHP_SESSION_NONE) session_start();
        if (empty($_SESSION['admin_logged_in'])) {
            header('Location: ../../public/assets/index.php?action=admin');
            exit();
        }
        $this->generateCsrfToken();

        $id = $_GET['id'] ?? null;
        if (!$id) {
            header('Location: ../../public/assets/index.php?action=admin_dashboard');
            exit();
        }

        $family = $this->adminModel->getFamilyById($id);
        $members = $this->adminModel->getMembersByFamily($id);
        $error = "";

        // Familiegegevens bewerken (inclusief ID)
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_family'])) {
            if (
                empty($_POST['csrf_token']) ||
                !$this->checkCsrfToken($_POST['csrf_token'])
            ) {
                $error = "Ongeldige sessie, probeer het opnieuw.";
            } else {
                $new_id = trim($_POST['id']);
                $naam = trim($_POST['naam']);
                $adres = trim($_POST['adres']);
                $korting = isset($_POST['korting']) ? floatval($_POST['korting']) : null;

                if (
                    !$new_id || strlen($new_id) > 20 ||
                    !$naam || strlen($naam) > 100 ||
                    !$adres || strlen($adres) > 255 ||
                    ($korting !== null && ($korting < 0 || $korting > 100))
                ) {
                    $error = "Ongeldige of ontbrekende invoer.";
                } else {
                    try {
                        // Als het ID is gewijzigd, update ook de members
                        if ($new_id !== $id) {
                            $this->adminModel->updateFamilyId($id, $new_id);
                            $id = $new_id;
                        }
                        $this->adminModel->updateFamilyId($id, $naam, $adres, $korting);
                        header('Location: ../../public/assets/index.php?action=edit_family&id=' . urlencode($id));
                        exit();
                    } catch (Exception $e) {
                        $error = "Er is iets misgegaan. Probeer het later opnieuw.";
                    }
                }
            }
        }

        // Lid bewerken
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_member_id'])) {
            if (
                empty($_POST['csrf_token']) ||
                !$this->checkCsrfToken($_POST['csrf_token'])
            ) {
                $error = "Ongeldige sessie, probeer het opnieuw.";
            } else {
                $member_id = intval($_POST['edit_member_id']);
                $member_naam = trim($_POST['edit_member_naam']);
                $leeftijd = filter_var($_POST['edit_member_leeftijd'], FILTER_VALIDATE_INT);
                $soort_lid = trim($_POST['edit_member_soort_lid']);
                $allowed_soorten = ['jeugd', 'aspirant', 'junior', 'senior', 'oudere'];

                if (
                    !$member_naam || strlen($member_naam) > 100 ||
                    !$leeftijd || $leeftijd <= 0 || $leeftijd > 120 ||
                    !in_array($soort_lid, $allowed_soorten)
                ) {
                    $error = "Ongeldige of ontbrekende invoer.";
                } else {
                    $this->adminModel->updateMember($member_id, $member_naam, $leeftijd, $soort_lid);
                    header("Location: ../../public/assets/index.php?action=edit_family&id=" . urlencode($id));
                    exit();
                }
            }
        }

        // Lid toevoegen
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_member'])) {
            if (
                empty($_POST['csrf_token']) ||
                !$this->checkCsrfToken($_POST['csrf_token'])
            ) {
                $error = "Ongeldige sessie, probeer het opnieuw.";
            } else {
                $member_naam = trim($_POST['member_naam']);
                $leeftijd = filter_var($_POST['leeftijd'], FILTER_VALIDATE_INT);
                $soort_lid = trim($_POST['soort_lid']);
                $allowed_soorten = ['jeugd', 'aspirant', 'junior', 'senior', 'oudere'];

                if (
                    !$member_naam || strlen($member_naam) > 100 ||
                    !$leeftijd || $leeftijd <= 0 || $leeftijd > 120 ||
                    !in_array($soort_lid, $allowed_soorten)
                ) {
                    $error = "Ongeldige of ontbrekende invoer.";
                } else {
                    $this->adminModel->addMember($id, $member_naam, $leeftijd, $soort_lid);
                    header("Location: ../../public/assets/index.php?action=edit_family&id=" . urlencode($id));
                    exit();
                }
            }
        }

        // Lid verwijderen
        if (isset($_GET['delete_member'])) {
            $member_id = intval($_GET['delete_member']);
            $this->adminModel->deleteMember($member_id);
            header("Location: ../../public/assets/index.php?action=edit_family&id=" . urlencode($id));
            exit();
        }

        // Herlaad members na eventuele wijzigingen
        $members = $this->adminModel->getMembersByFamily($id);

        require_once __DIR__ . '/../views/admin/edit_family.php';
    }

    public function confirm_delete_family()
    {
        if (session_status() === PHP_SESSION_NONE) session_start();
        if (empty($_SESSION['admin_logged_in'])) {
            header('Location: ../../public/assets/index.php?action=admin');
            exit();
        }
        $this->generateCsrfToken();

        $id = $_GET['id'] ?? null;
        if (!$id) {
            header('Location: ../../public/assets/index.php?action=admin_dashboard');
            exit();
        }

        $family = $this->adminModel->getFamilyById($id);
        $error = "";

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_delete'])) {
            // CSRF check
            if (
                empty($_POST['csrf_token']) ||
                !$this->checkCsrfToken($_POST['csrf_token'])
            ) {
                $error = "Ongeldige sessie, probeer het opnieuw.";
            } else {
                $this->adminModel->deleteFamily($id);
                header('Location: ../../public/assets/index.php?action=admin_dashboard');
                exit();
            }
        }

        require_once __DIR__ . '/../views/admin/confirm_delete_family.php';
    }

    public function admin_add_family()
    {
        if (session_status() === PHP_SESSION_NONE) session_start();
        if (empty($_SESSION['admin_logged_in'])) {
            header('Location: ../../public/assets/index.php?action=admin');
            exit();
        }
        $this->generateCsrfToken();

        $error = "";

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // CSRF check
            if (
                empty($_POST['csrf_token']) ||
                !$this->checkCsrfToken($_POST['csrf_token'])
            ) {
                $error = "Ongeldige sessie, probeer het opnieuw.";
            } else {
                // Input validatie
                $naam = trim($_POST['naam']);
                $adres = trim($_POST['adres']);
                $id_code = trim($_POST['ID']);
                $member_naam = trim($_POST['member_naam']);
                $member_leeftijd = filter_var($_POST['member_leeftijd'], FILTER_VALIDATE_INT);
                $member_soort = trim($_POST['member_soort']);
                $allowed_soorten = ['jeugd', 'aspirant', 'junior', 'senior', 'oudere'];

                if (
                    !$naam || strlen($naam) > 100 ||
                    !$adres || strlen($adres) > 255 ||
                    !$id_code || strlen($id_code) > 20 ||
                    !$member_naam || strlen($member_naam) > 100 ||
                    !$member_leeftijd || $member_leeftijd <= 0 || $member_leeftijd > 120 ||
                    !in_array($member_soort, $allowed_soorten)
                ) {
                    $error = "Ongeldige of ontbrekende invoer.";
                } else {
                    try {
                        $this->adminModel->addFamilyWithMember([
                            'naam' => htmlspecialchars($naam),
                            'adres' => htmlspecialchars($adres),
                            'id_code' => htmlspecialchars($id_code),
                            'member_naam' => htmlspecialchars($member_naam),
                            'member_leeftijd' => $member_leeftijd,
                            'member_soort' => htmlspecialchars($member_soort)
                        ]);
                        header('Location: ../../public/assets/index.php?action=admin_dashboard');
                        exit();
                    } catch (Exception $e) {
                        $error = "Er is iets misgegaan. Probeer het later opnieuw.";
                    }
                }
            }
        }

        require_once __DIR__ . '/../views/admin/admin_add_family.php';
    }

    public function admin_contributies()
    {
        if (session_status() === PHP_SESSION_NONE) session_start();
        if (empty($_SESSION['admin_logged_in'])) {
            header('Location: ../../public/assets/index.php?action=admin');
            exit();
        }
        $this->generateCsrfToken();

        require_once __DIR__ . '/../models/ContributieModel.php';
        require_once __DIR__ . '/../models/FamilyModel.php';
        require_once __DIR__ . '/../models/MemberModel.php';

        $contributieModel = new ContributieModel();
        $familyModel = new FamilyModel();
        $memberModel = new MemberModel();

        $jaar = isset($_GET['jaar']) ? intval($_GET['jaar']) : date('Y');
        $families = $familyModel->getAllFamilies();

        $selected_family_id = $_GET['family_id'] ?? ($families[0]['id'] ?? null);

        if (isset($_GET['delete_contributie'])) {
            $contributieId = intval($_GET['delete_contributie']);
            $contributieModel->deleteContributie($contributieId);
            header("Location: ../../public/assets/index.php?action=admin_contributies&family_id=" . urlencode($selected_family_id) . "&jaar=" . $jaar);
            exit();
        }

        if ($selected_family_id) {
            $contributies = $contributieModel->getContributiesByFamily($selected_family_id, $jaar);
            $members = $memberModel->getMembersByFamily($selected_family_id);
        }

        $error = "";

        // Contributie toevoegen
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_contributie'])) {
            if (
                empty($_POST['csrf_token']) ||
                !$this->checkCsrfToken($_POST['csrf_token'])
            ) {
                $error = "Ongeldige sessie, probeer het opnieuw.";
            } else {
                $member_id = intval($_POST['member_id']);
                $jaar_post = intval($_POST['jaar']);
                $bedrag = floatval($_POST['bedrag']);

                if (!$member_id || !$jaar_post || $bedrag < 0) {
                    $error = "Ongeldige invoer.";
                } else {
                    $contributieModel->addContributie($member_id, $jaar_post, $bedrag);
                    header("Location: ../../public/assets/index.php?action=admin_contributies&family_id=" . urlencode($selected_family_id) . "&jaar=" . $jaar_post);
                    exit();
                }
            }
        }

        require __DIR__ . '/../views/admin/contributies.php';
    }
}
