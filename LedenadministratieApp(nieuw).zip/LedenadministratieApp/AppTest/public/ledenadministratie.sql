-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Gegenereerd op: 02 jul 2025 om 15:39
-- Serverversie: 10.4.32-MariaDB
-- PHP-versie: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ledenadministratie`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `admins`
--

INSERT INTO `admins` (`id`, `username`, `password`, `created_at`) VALUES
(3, 'admin', '$2y$10$8vXUmfZyPOWDh49nQ5KKzu8kyNc8kBMeRRve1Yf2U4kuwLwJxKwge', '2025-05-12 08:49:54');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `boekjaar`
--

CREATE TABLE `boekjaar` (
  `id` int(11) NOT NULL,
  `jaar` year(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `boekjaar`
--

INSERT INTO `boekjaar` (`id`, `jaar`) VALUES
(1, '2025');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `contributies`
--

CREATE TABLE `contributies` (
  `id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `jaar` int(11) NOT NULL,
  `bedrag` decimal(8,2) NOT NULL,
  `betaald` tinyint(1) DEFAULT 0,
  `betaald_op` date DEFAULT NULL,
  `opmerkingen` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `contributies`
--

INSERT INTO `contributies` (`id`, `member_id`, `jaar`, `bedrag`, `betaald`, `betaald_op`, `opmerkingen`) VALUES
(3, 25, 2025, 25.00, 0, NULL, NULL),
(4, 26, 2025, 25.00, 0, NULL, NULL),
(5, 28, 2025, 27.50, 0, NULL, NULL),
(6, 29, 2025, 50.00, 0, NULL, NULL),
(7, 27, 2025, 45.10, 0, NULL, NULL),
(8, 4, 2025, 49.50, 0, NULL, NULL),
(9, 7, 2025, 49.50, 0, NULL, NULL),
(10, 8, 2025, 49.50, 0, NULL, NULL),
(11, 9, 2025, 45.00, 0, NULL, NULL),
(12, 34, 2025, 100.00, 0, NULL, NULL),
(13, 32, 2025, 100.00, 0, NULL, NULL),
(15, 10, 2025, 100.00, 0, NULL, NULL),
(16, 11, 2025, 100.00, 0, NULL, NULL),
(17, 12, 2025, 75.00, 0, NULL, NULL),
(18, 31, 2025, 75.00, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `families`
--

CREATE TABLE `families` (
  `id` int(11) NOT NULL,
  `naam` varchar(255) NOT NULL,
  `adres` text NOT NULL,
  `boekjaar_id` int(11) DEFAULT NULL,
  `korting` decimal(5,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `families`
--

INSERT INTO `families` (`id`, `naam`, `adres`, `boekjaar_id`, `korting`) VALUES
(101, 'Pannenkoek', 'Pannenkoekstraat 1A', 1, 0.00),
(111, 'Miralles', 'Kees Pijlstraat 25', 1, 0.00),
(222, 'Gomez Ruiz', 'Louis Pregerkade 148', 1, 0.50),
(777, 'Henriquez', 'Oranjeboomstraat 207b ', 1, 0.10),
(1234, 'Testerman', 'Teststraat 123', 1, 0.25),
(8365, 'Gonzalez', 'Calle Conrado del Campo 5B', 1, 0.18),
(9876, 'Poolsen', 'Franselaan 244a', 1, 0.00);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `members`
--

CREATE TABLE `members` (
  `id` int(11) NOT NULL,
  `family_id` int(11) NOT NULL,
  `naam` varchar(255) NOT NULL,
  `leeftijd` int(11) NOT NULL,
  `soort_lid` enum('jeugd','aspirant','junior','senior','oudere') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `members`
--

INSERT INTO `members` (`id`, `family_id`, `naam`, `leeftijd`, `soort_lid`) VALUES
(4, 777, 'Juan Henriquez', 55, 'oudere'),
(7, 777, 'Juana Henriquez', 53, 'oudere'),
(8, 777, 'Juancho Pancho', 24, 'oudere'),
(9, 777, 'Juanita', 13, 'jeugd'),
(10, 9876, 'Enrique Poolsen', 28, 'senior'),
(11, 9876, 'Enrica Poolsen ', 27, 'senior'),
(12, 1234, 'Test Man', 25, 'senior'),
(25, 222, 'Sergio Gomez Ruiz', 20, 'jeugd'),
(26, 222, 'Sofia Gomez Ruiz', 11, 'jeugd'),
(27, 8365, 'Maria Gonzalez', 65, 'oudere'),
(28, 222, 'Jose Gomez', 57, 'oudere'),
(29, 222, 'Sara Ruiz Marin', 49, 'senior'),
(31, 1234, 'Test Vrouw', 25, 'senior'),
(32, 101, 'Meneer Pannenkoek', 49, 'senior'),
(34, 111, 'Miguel Miralles', 52, 'senior');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `soort_lid`
--

CREATE TABLE `soort_lid` (
  `id` int(11) NOT NULL,
  `omschrijving` varchar(50) NOT NULL,
  `min_leeftijd` int(11) DEFAULT NULL,
  `max_leeftijd` int(11) DEFAULT NULL,
  `korting` decimal(5,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Gegevens worden geëxporteerd voor tabel `soort_lid`
--

INSERT INTO `soort_lid` (`id`, `omschrijving`, `min_leeftijd`, `max_leeftijd`, `korting`) VALUES
(1, 'Jeugd', 0, 7, 50.00),
(2, 'Aspirant', 8, 12, 40.00),
(3, 'Junior', 13, 17, 25.00),
(4, 'Senior', 18, 50, 0.00),
(5, 'Oudere', 51, 120, 45.00);

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexen voor tabel `boekjaar`
--
ALTER TABLE `boekjaar`
  ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `contributie`
--
ALTER TABLE `contributie`
  ADD PRIMARY KEY (`id`),
  ADD KEY `boekjaar_id` (`boekjaar_id`),
  ADD KEY `soort_lid_id` (`soort_lid_id`);

--
-- Indexen voor tabel `contributies`
--
ALTER TABLE `contributies`
  ADD PRIMARY KEY (`id`),
  ADD KEY `member_id` (`member_id`);

--
-- Indexen voor tabel `families`
--
ALTER TABLE `families`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_families_boekjaar` (`boekjaar_id`);

--
-- Indexen voor tabel `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`id`),
  ADD KEY `family_id` (`family_id`);

--
-- Indexen voor tabel `soort_lid`
--
ALTER TABLE `soort_lid`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT voor een tabel `boekjaar`
--
ALTER TABLE `boekjaar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT voor een tabel `contributie`
--
ALTER TABLE `contributie`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT voor een tabel `contributies`
--
ALTER TABLE `contributies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT voor een tabel `families`
--
ALTER TABLE `families`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9887;

--
-- AUTO_INCREMENT voor een tabel `members`
--
ALTER TABLE `members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT voor een tabel `soort_lid`
--
ALTER TABLE `soort_lid`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Beperkingen voor geëxporteerde tabellen
--

--
-- Beperkingen voor tabel `contributie`
--
ALTER TABLE `contributie`
  ADD CONSTRAINT `contributie_ibfk_1` FOREIGN KEY (`boekjaar_id`) REFERENCES `boekjaar` (`id`),
  ADD CONSTRAINT `contributie_ibfk_2` FOREIGN KEY (`soort_lid_id`) REFERENCES `soort_lid` (`id`);

--
-- Beperkingen voor tabel `contributies`
--
ALTER TABLE `contributies`
  ADD CONSTRAINT `contributies_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE;

--
-- Beperkingen voor tabel `families`
--
ALTER TABLE `families`
  ADD CONSTRAINT `fk_families_boekjaar` FOREIGN KEY (`boekjaar_id`) REFERENCES `boekjaar` (`id`);

--
-- Beperkingen voor tabel `members`
--
ALTER TABLE `members`
  ADD CONSTRAINT `members_ibfk_1` FOREIGN KEY (`family_id`) REFERENCES `families` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
