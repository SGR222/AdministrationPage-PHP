<?php
require_once __DIR__ . '/../../controllers/FamilyController.php';
require_once __DIR__ . '/../../controllers/AuthController.php';
require_once __DIR__ . '/../../controllers/AdminController.php';

$action = $_GET['action'] ?? 'index';

switch ($action) {
    case 'login':
    case 'logout':
    case 'admin':
        $controller = new AuthController();
        break;
    case 'admin_dashboard':
    case 'edit_family':
    case 'confirm_delete_family':
    case 'admin_add_family':
    case 'admin_contributies':
        $controller = new AdminController();
        break;
    default:
        $controller = new FamilyController();
        break;
}

if (method_exists($controller, $action)) {
    $controller->$action();
} else {
    echo "Pagina niet gevonden.";
}
