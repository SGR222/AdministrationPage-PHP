<?php
class Database
{
    private $host = 'localhost';
    private $db_name = 'ledenadministratie';
    private $username = 'root';
    private $password = '@DatabaseMan222';
    private $conn;

    public function getConnection()
    {
        if ($this->conn !== null) {
            return $this->conn;
        }

        try {
            $dsn = "mysql:host={$this->host};dbname={$this->db_name};charset=utf8mb4";
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ];

            $this->conn = new PDO($dsn, $this->username, $this->password, $options);
        } catch (PDOException $exception) {
            throw new Exception("Database connectie fout: " . $exception->getMessage());
        }

        return $this->conn;
    }
}
